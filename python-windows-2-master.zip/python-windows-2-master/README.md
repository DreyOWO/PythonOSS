# Python Lab 2

> **The purpose of this repository is intended just for troubleshooting training material and it is not recommended to take this as a reference for production scenarios**.